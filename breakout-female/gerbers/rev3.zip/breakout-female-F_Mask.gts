%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-11-13T11:29:05-08:00*%
%TF.ProjectId,breakout-female,62726561-6b6f-4757-942d-66656d616c65,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-11-13 11:29:05*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
%AMHorizOval*
0 Thick line with rounded ends*
0 $1 width*
0 $2 $3 position (X,Y) of the first rounded end (center of the circle)*
0 $4 $5 position (X,Y) of the second rounded end (center of the circle)*
0 Add line between two ends*
20,1,$1,$2,$3,$4,$5,0*
0 Add two circle primitives to create the rounded ends*
1,1,$1,$2,$3*
1,1,$1,$4,$5*%
G04 Aperture macros list end*
%ADD10C,1.600000*%
%ADD11C,3.200000*%
%ADD12O,2.000000X3.500000*%
%ADD13HorizOval,2.000000X0.530330X0.530330X-0.530330X-0.530330X0*%
%ADD14HorizOval,2.000000X-0.530330X0.530330X0.530330X-0.530330X0*%
%ADD15RoundRect,0.250000X-0.625000X0.350000X-0.625000X-0.350000X0.625000X-0.350000X0.625000X0.350000X0*%
%ADD16O,1.750000X1.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,J1*%
X47550000Y-90700000D03*
X48590000Y-71150000D03*
X57910000Y-71150000D03*
D11*
X59500000Y-81000000D03*
D12*
X47000000Y-81000000D03*
D11*
X53250000Y-87250000D03*
X61700000Y-91800000D03*
D13*
X57250000Y-87250000D03*
X56470711Y-84150711D03*
D11*
X46280000Y-84780000D03*
D14*
X49959289Y-84150711D03*
D13*
X47520000Y-77390000D03*
D11*
X51140000Y-76180000D03*
%TD*%
D15*
%TO.C,J2*%
X62880000Y-70550000D03*
D16*
X62880000Y-72550000D03*
X62880000Y-74550000D03*
X62880000Y-76550000D03*
%TD*%
M02*
